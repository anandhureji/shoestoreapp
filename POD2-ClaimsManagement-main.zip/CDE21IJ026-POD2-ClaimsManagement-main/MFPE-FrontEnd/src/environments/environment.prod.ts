export const environment = {
  production: true,
  AUTH_SERVICE_URL: 'http://54.144.226.79:9797/authorization1/authorization',
  MEMBER_SERVICE_URL: 'http://54.144.226.79:9797/memberModule1/memberModule',
};
 