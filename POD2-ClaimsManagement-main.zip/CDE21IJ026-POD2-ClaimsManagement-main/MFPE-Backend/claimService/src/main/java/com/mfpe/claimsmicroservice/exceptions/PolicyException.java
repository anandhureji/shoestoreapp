package com.mfpe.claimsmicroservice.exceptions;

public class PolicyException extends RuntimeException{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public PolicyException(String message) {
		super(message);
	}
}
