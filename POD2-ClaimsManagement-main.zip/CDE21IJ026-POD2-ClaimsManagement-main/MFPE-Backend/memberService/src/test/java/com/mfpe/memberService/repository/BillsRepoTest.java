package com.mfpe.memberService.repository;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class BillsRepoTest {

}